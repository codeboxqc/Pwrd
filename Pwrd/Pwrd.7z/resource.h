//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Pwrd.rc
//
#define IDC_MYICON                      2
#define IDS_APP_TITLE                   1103
#define IDM_ABOUT                       304
#define IDM_EXIT                        105
#define IDI_PWRD                        107
#define IDC_PWRD                        109
#define IDC_LISTVIEW                    1000
#define IDC_NAME                        1001
#define IDC_WEBSITE                     1002
#define IDC_EMAIL                       1003
#define IDC_USER                        1004
#define IDC_PASSWORD                    1005
#define IDC_NOTE                        1006
#define IDC_ADD                         1007
#define IDC_DELETE                      1008
#define IDC_SEARCH                      1009
#define IDC_SEARCH_EDIT                 1010
#define IDC_COLOR                       1011
#define IDC_COPY_NAME                   1012
#define IDC_COPY_WEBSITE                1013
#define IDC_COPY_EMAIL                  1014
#define IDC_COPY_USER                   1015
#define IDC_COPY_PASSWORD               1016
#define IDC_COPY_NOTE                   1017
#define IDC_COPY_COLOR                  1018
#define IDC_AutoBtn                    1019
#define IDC_XBtn                       1020
#define IDC_MidBtn 1021
#define IDC_LowBtn  1022
#define  IDC_reset 1023
#define IDC_UPDATE_BUTTON 1024


#define  IDC_EDIT_PIN 1025
#define IDD_PASSWORD_DIALOG            1026
#define IDC_STATIC_PROMPT              1027
 

#define IDC_STATIC                      -1

#define IDB_BITMAP1                     129
#define IDC_CURSOR1                     222
#define IDI_SMALL                       108
 
#define IDD_ABOUTBOX                    103

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif

